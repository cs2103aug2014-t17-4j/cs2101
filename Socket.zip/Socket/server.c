#include "socket_header.h"

#define BACKLOG 10

void operate(int fd, int droprate);

int main(void) {
	//Declare Variables
	int sock_fd, conn_fd, ret_val;
	
	//Declare Structures to represent IPv4 Addresses
	struct sockaddr_in local_addr;
	struct sockaddr_in remote_addr;
	socklen_t sin_size;
	
	//Used for Multi-Thread purposes
	pid_t pid;

	//Input TCP Port	
	int tcp_port;
	printf("Please enter TCP Port: ");
	scanf("%d",&tcp_port);
	
	//Input Drop Rate
	int droprate;
	printf("Please enter drop rate (%%): ");
	scanf("%d",&droprate);


	//Set up a Socket
	sock_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (sock_fd<0) {
		printf("Socket Error\n");
		exit(1);
	}
	printf("Socket Success\n");
	
	//Initialize Local Address
	local_addr.sin_family = AF_INET;
	local_addr.sin_port = htons(tcp_port);
	local_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(local_addr.sin_zero), 8);
	
	//Bind Socket to Local Address
	ret_val = bind(sock_fd, (struct sockaddr *) &local_addr, sizeof(struct sockaddr));
	if (ret_val<0) {
		printf("Bind Error\n");
		exit(1);
	}
	printf("Bind Success\n");
	
	//Listen to Socket
	ret_val = listen(sock_fd, BACKLOG);
	if (ret_val<0) {
		printf("Listen Error\n");
		exit(1);
	}
	printf("Listen Success\n");

	//Begin Continuous Operation
	while(1) {
		//Accept a Connection (Blocking)
		sin_size = sizeof(struct sockaddr_in);
		conn_fd = accept(sock_fd, (struct sockaddr *) &remote_addr, &sin_size);
		if (conn_fd<0) {
			printf("Accept Error\n");
			exit(1);
		}
		printf("Accept Success\n");
		
		//Split Instance
		pid = fork();
		if (pid == 0) {
			//Child Instance
			close(sock_fd);
			operate(conn_fd, droprate);
			close(conn_fd);
			exit(0);
		} else {
			//Parent Instance
			close (conn_fd);
		}
	}
	
	//Clean Up
	close(sock_fd);
	exit(0);
}

void operate(int fd, int droprate) {
	//Declare Variables
	char complete_buf[BUF_SIZE];
	int end = 0, n = 0;
	long seek_pos = 0;
	struct pack_so packet;
	struct ack_so ack;
	FILE *file;

	//Seed Random Generator
	srand(time(0));

	//Start from ACK 0
	ack.num = 0;
	ack.len = 0;

	//Negotiate Data Size
	int data_len;
	n = recv(fd, &data_len, 4, 0);
	if (n<0) {
		printf("Data Size Error");
		exit(1);
	}
	printf("Data Size Success (%d)\n", data_len);

	long totalReceived = 0;
	while(!end) {		
		//Receive one data_len of Data + 64 bit Header
		n = recv(fd, &packet, data_len+HEAD_LEN, 0);
		
		if (n<0) {
			printf("Receive Error\n");
			exit(1);
		}

		int initial_packet_length = packet.len;
		int packet_remaining = packet.len + HEAD_LEN - n;
		int next_write = n - HEAD_LEN;
		totalReceived += n - HEAD_LEN;

		// Receive Packet Fragments
		while (next_write > 0 && packet_remaining > 0) {
			n = recv(fd, &packet.data[next_write], packet_remaining, 0);
			if (n > 0) {				
				packet_remaining = packet_remaining - n;
			
				next_write = next_write + n;
			}
		}

		//Check if last byte has Terminator.
		if (initial_packet_length != data_len && packet.data[packet.len-1] == '\0') {
			printf("Terminator Received %d\n",packet.num);
			end = 1;
		}
		
		//Check if Packet number is expected (i.e. same as last ACK).
		if (packet.num==ack.num) {
			//Copy data into Buffer
			memcpy(complete_buf+seek_pos, packet.data, packet.len);
			//Toggle ACK
			ack.num = ack.num^0x1;
			//Increment Seek Position
			seek_pos += packet.len;
		}

		//Simulate Lossy Environment based on Drop Rate.
		if ((rand()%100)<(100-droprate)) {
			n = send(fd, &ack, 2, 0);
		} else {
			n = 2;
		}
		if (n<0) {
				printf("ACK Error\n");
				exit(1);
		}
	}

	//Prevent terminator from being copied.	
	seek_pos--;
	
	//Write the File
	file = fopen("receive.txt","wt");
	if (file == NULL) {
		printf("File Error\n");
		exit(1);
	}
	fwrite(complete_buf, 1, seek_pos, file);
	fclose(file);
	printf("File Success: (%d Bytes)\n\n", (int)seek_pos);
}
