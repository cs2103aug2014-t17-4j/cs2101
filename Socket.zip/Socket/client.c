#include "socket_header.h"

void  operate(FILE *file, int sock_fd, int drop_rate, int data_len);
void time_difference(struct timeval *out, struct timeval *in);

int main(int argc, char **argv) {
	//Declare Variables
	int sock_fd, ret_val;
	FILE *file;

	//Variables for Nameserver Querying
	char **pptr;
	struct sockaddr_in ser_addr;
	struct hostent *ser_hostent;
	struct in_addr **addrs;

	//Seed Random Generator
	srand(time(0));
	
	//Check for correct parameters
	if (argc!=2) {
		printf("Parameter Error\n");
		exit(1);
	}
	
	//Perform DNS Query
	ser_hostent = gethostbyname(argv[1]);
	if (ser_hostent == NULL) {
		printf("DNS Error\n");
		exit(1);
	}
	
	//Print Server Information
	printf("\n");
	printf("==============\n");
	printf("Target Summary\n");
	printf("==============\n");
	printf("\n");
	printf("Canonical Name: %s\n",ser_hostent->h_name);
	for (pptr=ser_hostent->h_aliases; *pptr != NULL; pptr++) {
		printf("Alias: %s\n",*pptr);
	}
	printf("Address Type: ");
	switch(ser_hostent->h_addrtype) {
		case AF_INET:
			printf("AF_INET\n");
		break;
		default:
			printf("Unknown\n");
		break;
	}
	
	//Shortcut variable for accessing list of addresses from DNS.
	addrs = (struct in_addr **) ser_hostent->h_addr_list;

	printf("\n");
	printf("==============\n");
	printf("Transfer Setup\n");
	printf("==============\n");
	printf("\n");

	//Input TCP Port	
	int tcp_port;
	printf("Please enter TCP Port: ");
	scanf("%d",&tcp_port);

	//Input Drop Rate	
	int drop_rate;
	printf("Please enter drop rate (percentage): ");
	scanf("%d",&drop_rate);

	//Input Receive Timeout
	int timeout;
	printf("Please enter RECV timeout (ms): ");
	scanf("%d", &timeout);

	//Input Data Size
	int data_len;
	printf("Please enter data size (bytes): ");
	scanf("%d", &data_len);

	printf("\n");
	printf("==================\n");
	printf("Transfer Operation\n");
	printf("==================\n");
	printf("\n");

	//Set up a Socket
	sock_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (sock_fd<0) {
		printf("Socket Error!\n\n");
		exit(1);
	}
	printf("Socket Success...\n");
	
	//Set up Server Address
	ser_addr.sin_family = AF_INET;
	ser_addr.sin_port = htons(tcp_port);
	memcpy(&(ser_addr.sin_addr.s_addr), *addrs, sizeof(struct in_addr));
	bzero(&(ser_addr.sin_zero), 8);

	//Connect to Server
	ret_val = connect(sock_fd, (struct sockaddr *) &ser_addr, sizeof(struct sockaddr));
	if (ret_val<0) {
		printf("Connect Error!\n\n");
		exit(1);
	}
	printf("Connect Success...\n");

	//Set Timeout parameters
	const struct timeval sock_timeout={.tv_sec=0, .tv_usec=timeout*1000};
	if (setsockopt(sock_fd, SOL_SOCKET, SO_RCVTIMEO, (char*)&sock_timeout, sizeof(sock_timeout)) < 0) {
		perror("Error");
	}

	//Open File for Sending
	file = fopen("send.txt","rt");
	if (file == NULL) {
		printf("File Error\n\n");
		exit(0);
	}

	printf("Transferring Data...\n");
	operate(file, sock_fd, drop_rate, data_len);
	
	//Clean Up
	close(sock_fd);
	fclose(file);
	exit(0);
}

void operate(FILE *file, int sock_fd, int drop_rate, int data_len) {
	//Declare Variables
	char *complete_buf;
	long file_size, seek_pos = 0;
	struct pack_so packet;
	struct ack_so ack;
	int n, m, send_len;
	struct timeval send_time, receive_time;
	float time_passed = 0.0;
	packet.num = 0;
	ack.num = 0;
	long original_packets = 0;
	long timeouts = 0;
	long total_packets_sent = 0;
	long packets_dropped = 0;
	long wrong_acks = 0;
	
	//Negotiate Data Size
	n = send(sock_fd, &data_len, 4, 0);
	if (n<0) {
		printf("Data Size Error!\n\n");
		exit(1);	
	}
	
	//Find File Size
	fseek(file , 0 , SEEK_END);
	file_size = ftell(file);
	rewind(file);
	
	//Allocate Buffer for File
	complete_buf = (char *) malloc(file_size+1);
	if (complete_buf == NULL) {
		printf("Memory Allocation Error!\n\n");
		exit(1);
	}
	
	//Read File into Buffer
	fread(complete_buf, 1, file_size, file);
	
	//Add Terminator to the end
	complete_buf[file_size] = '\0';

	//Start Timing
	gettimeofday(&send_time, NULL);

	//Begin Sending File
	while (seek_pos <= file_size) {
		//Determine correct data length (in case remaining data is less than data_len).
		if ((file_size+1-seek_pos)<=data_len) {
			send_len = file_size+1-seek_pos;
		} else {
			send_len = data_len;
		}
		
		//Copy send_len amount into send buffer.
		memcpy(packet.data, (complete_buf+seek_pos), send_len);
		
		//Correct packet length
		packet.len = send_len;
		
		//Simulate lossy environment based on drop rate
		if ((rand()%100)<(100-drop_rate)) {;
			n = send(sock_fd, &packet, send_len+HEAD_LEN, MSG_NOSIGNAL);
		} else {
			n = send_len + HEAD_LEN;
			packets_dropped++;
		}
		if (n<0) {
			exit(1);
		}

		total_packets_sent++;

		//Receive an ACK (Blocking with timeout)
		m = recv(sock_fd, &ack, 2, 0);
		if (m == 1) {
			printf("M IS ONE");		
		}
		if (m<0) {
			timeouts++;
		} else if (m==2 && ack.num == packet.num) {
			wrong_acks++;
		} else if (m==2 && ack.num != packet.num) {
			//If correct ACK received, increment Seek Position and toggle Packet Number.
			seek_pos += send_len;
			packet.num = packet.num^0x1;
			original_packets++;
		}
	}
	
	//Record Ending Time.
	gettimeofday(&receive_time, NULL);
	//Find difference in ms.
	time_difference(&receive_time, &send_time);
	//Store as a plain integer.
	time_passed += receive_time.tv_sec*1000.0 + receive_time.tv_usec/1000.0;
	//Calculate the Rate
	float rate = (seek_pos/(float)time_passed);
	
	//Show Statistics
	printf("\n");
	printf("================\n");
	printf("Transfer Summary\n");
	printf("================\n");
	printf("\n");
	printf("                  File length:\t%d Bytes\n", (int)file_size);
	printf("                         Time:\t%.3f ms\n", time_passed);
	printf("                    Data sent:\t%d Bytes\n", (int)seek_pos);
	printf("                    Data rate:\t%f KBytes/s\n", rate);
	printf("\n");
	printf("             Original Packets:\t%ld\n",original_packets);
	printf("Retransmissions (ACK Timeout):\t%ld\n",timeouts);
	printf("  Retransmissions (Wrong ACK):\t%ld\n",wrong_acks);
	printf("           Total Packets Sent:\t%ld\n",total_packets_sent);
	printf("\n");
	printf("       Simulated Packet Drops:\t%ld\n",packets_dropped);
	printf("\n");
}

void time_difference(struct timeval *out, struct timeval *in)
{
	if ((out->tv_usec -= in->tv_usec)<0)
	{
		--out->tv_sec;
		out->tv_usec += 1000000;
	}
	out->tv_sec -= in->tv_sec;
}
