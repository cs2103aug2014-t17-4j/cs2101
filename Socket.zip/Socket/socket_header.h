//Standard Include Libraries
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <strings.h>
#include <time.h>

//Other Constants
#define BUF_SIZE 1000000
#define DATA_LEN 1000000
#define HEAD_LEN 8

//Packet Structure
struct pack_so {
	uint32_t num; //Sequence Number
	uint32_t len; //Length
	char data[DATA_LEN];
};

//ACK Structure
struct ack_so {
	uint8_t num; //Sequence Number
	uint8_t len; //Length
};
